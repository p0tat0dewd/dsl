#include<stdio.h>
int bsr(int arr[],int l,int r,int key){
    if(l<=r){
        int mid=l+(r-l)/2;
        if(arr[mid]==key){
            return mid;
        }
        else if(arr[mid]<key){
            return bsr(arr,mid+1,r,key);
        }
        else{
            return bsr(arr,l,mid-1,key);
        }
    }
    return -1;
}
int main(){
    int arr[]={1,2,3,4,5,6,7,8,9};
    int n=sizeof(arr)/sizeof(arr[0]);
    int key=3;
    int f=bsr(arr,0,n-1,key);
    if(f!=-1){
        printf("element found at %d",f);
    }
    else{
        printf("element not found.");
    }
}
