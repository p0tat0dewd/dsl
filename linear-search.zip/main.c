#include<stdio.h>
int ls(int arr[],int n,int key){
    int i;
    for(i=0;i<n;i++){
        if((arr[i])==key){
            return i;
        }
    }
    return -1;
}
int main(){
    int arr[]={11,12,13,1,45,6,7,8,9};
    int key=20;
    int n=sizeof(arr)/sizeof(arr[0]);
    int r=ls(arr,n,key);
    if(r!=-1){
        printf("element at index %d\n",r);
    }
    else{
        printf("element not found.");
    }
}