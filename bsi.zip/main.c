#include<stdio.h>
int bsi(int arr[],int n,int key){
    int l=0;
    int r=n-1;
    while(l<=r){
        int mid=l+(r-l)/2;
        if(arr[mid]==key){
            return mid;
        }
        else if(arr[mid]<key){
            l=mid+1;
        }
        else{
            r=mid-1;
        }
    }
    return -1;
}
int main(){
    int arr[]={1,2,3,4,5,6,7,8,9};
    int n=sizeof(arr)/sizeof(arr[0]);
    int key=6;
    int f=bsi(arr,n,key);
    if(f!=-1){
        printf("element found at %d",f);
    }
    else{
        printf("element not found.");
    }
}