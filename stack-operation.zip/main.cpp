#include<stdio.h>
#include<stdlib.h>
#define MAX 10
int count=0;
//creating stack
struct stack{
    int items[MAX];
    int top;
};
typedef struct stack st;
void createstack(st *s){
    s->top=-1;
}
//check if full 
int isfull(st *s){
    if(s->top==MAX-1)
       return 1;
    else
       return 0;
}
//check if empty
int isempty(st *s){
    if(s->top==-1)
      return 1;
    else
      return 0;
}
//add elements
void push(st *s,int newitem){
    if(isfull(s)){
        printf("stack is full my blind ass nigga\n");
    }
    else{
        s->top++;
        s->items[s->top]=newitem;
    }
    count++;
}
//delete elements
void pop(st *s){
    if(isempty(s)){
        printf("stack empty.\n");
    }
    else{
        printf("item popipopipopipo=%d",s->items[s->top]);
        s->top--;
    }
    count--;
    printf("\n");
}
//print elements
void display(st*s){
    printf("staaaaaaaaaaack:");
    for(int i=0;i<count;i++){
        printf("%d",s->items[i]);
    }
    printf("\n");
}
int main(){
    st *s=(st*)malloc(sizeof(st));
    createstack(s);
    push(s,1);
    push(s,2);
    push(s,3);
    push(s,4);
    display(s);
    pop(s);
    pop(s);
    printf("\nAfter pooping out:\n");
    display(s);
}